from setuptools import setup

setup(
    name='square',
    version=1.0,
    description='This module calculate area and perimeter of square',
    author='OVV',
    author_email='vane.ov96@gmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['square']
    )