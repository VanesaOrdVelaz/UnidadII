import math
def square_perimeter(a: float) -> float:
    return 4 * a

def square_area(a: float) -> float:
    return a**2